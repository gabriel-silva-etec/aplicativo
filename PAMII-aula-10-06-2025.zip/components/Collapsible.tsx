// Criação de Página com os seguintes componentes:

// Botão que receberá a propriedade text: <Button text="exemplo" />

// Menu que recebra o nome do usuário: <Menu user="João"/>

// Instale a biblioteca react-router-dom e crie uma página chamada galeria,
// que devera ser acessada no seguinte endereço:

// Enviar para: gabriel.silva4087@etec.sp.gov.br